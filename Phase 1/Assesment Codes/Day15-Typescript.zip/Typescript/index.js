var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var ContactManager = /** @class */ (function () {
    function ContactManager() {
        this.contacts = [];
        this.currentId = 1;
    }
    ContactManager.prototype.addContact = function (contact) {
        contact.id = this.currentId++;
        this.contacts.push(contact);
        console.log("Contact added: ".concat(contact.name));
    };
    ContactManager.prototype.viewContacts = function () {
        if (this.contacts.length === 0) {
            console.log("No contacts available.");
            return [];
        }
        return this.contacts;
    };
    ContactManager.prototype.modifyContact = function (id, updatedContact) {
        var contactIndex = this.contacts.findIndex(function (contact) { return contact.id === id; });
        if (contactIndex === -1) {
            console.log("Error: Contact not found.");
            return;
        }
        this.contacts[contactIndex] = __assign(__assign({}, this.contacts[contactIndex]), updatedContact);
        console.log("Contact with ID ".concat(id, " has been updated."));
    };
    ContactManager.prototype.deleteContact = function (id) {
        var contactIndex = this.contacts.findIndex(function (contact) { return contact.id === id; });
        if (contactIndex === -1) {
            console.log("Error: Contact not found.");
            return;
        }
        this.contacts.splice(contactIndex, 1);
        console.log("Contact with ID ".concat(id, " has been deleted."));
    };
    return ContactManager;
}());
// Testing the ContactManager
var manager = new ContactManager();
// Add contacts
manager.addContact({ id: 0, name: 'Cristiano Ronaldo', email: 'Cristiano@ronaldo.com', phone: '8932298384' });
manager.addContact({ id: 0, name: 'Neymar Jr', email: 'Neymar@jr.com', phone: '8392939823' });
// View contacts
console.log(manager.viewContacts());
// Modify a contact
manager.modifyContact(1, { phone: '111-222-3333' });
manager.modifyContact(3, { phone: '000-000-0000' }); // To check an error
// Delete a contact
manager.deleteContact(2);
manager.deleteContact(3); // To check an error
// View contacts after modification and deletion
console.log(manager.viewContacts());
