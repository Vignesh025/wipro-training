﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SingletonPattern
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Logger  firstinstance=Logger.logger;
            Logger secondinstance=Logger.logger;
            if (firstinstance == secondinstance)
            {
                Console.WriteLine("Both the Instances are same.");
            }
            else {
                Console.WriteLine("Both the Instances are different");
            }
        }
    }
}
