interface Contact {
    id: number;
    name: string;
    email: string;
    phone: string;
  }

  class ContactManager {
    private contacts: Contact[] = [];
    private currentId: number = 1; 
  
    addContact(contact: Contact): void {
      contact.id = this.currentId++;
      this.contacts.push(contact);
      console.log(`Contact added: ${contact.name}`);
    }
  
    viewContacts(): Contact[] {
      if (this.contacts.length === 0) {
        console.log("No contacts available.");
        return [];
      }
      return this.contacts;
    }
  
    modifyContact(id: number, updatedContact: Partial<Contact>): void {
      const contactIndex = this.contacts.findIndex(contact => contact.id === id);
      if (contactIndex === -1) {
        console.log("Error: Contact not found.");
        return;
      }
      this.contacts[contactIndex] = { ...this.contacts[contactIndex], ...updatedContact };
      console.log(`Contact with ID ${id} has been updated.`);
    }
  
    deleteContact(id: number): void {
      const contactIndex = this.contacts.findIndex(contact => contact.id === id);
      if (contactIndex === -1) {
        console.log("Error: Contact not found.");
        return;
      }
      this.contacts.splice(contactIndex, 1);
      console.log(`Contact with ID ${id} has been deleted.`);
    }
  }
  

  // Testing the ContactManager
const manager = new ContactManager();

// Add contacts
manager.addContact({ id: 0, name: 'Cristiano Ronaldo', email: 'Cristiano@ronaldo.com', phone: '8932298384' });
manager.addContact({ id: 0, name: 'Neymar Jr', email: 'Neymar@jr.com', phone: '8392939823' });

// View contacts
console.log(manager.viewContacts());

// Modify a contact
manager.modifyContact(1, { phone: '111-222-3333' });
manager.modifyContact(3, { phone: '000-000-0000' }); // To check an error

// Delete a contact
manager.deleteContact(2);
manager.deleteContact(3); // To check an error

// View contacts after modification and deletion
console.log(manager.viewContacts());
