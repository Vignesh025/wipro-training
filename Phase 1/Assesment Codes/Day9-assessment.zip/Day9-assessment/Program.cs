﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Day9_assessment;
using NLog;


namespace Day9_assessment
{
    public class MenuAuth
    {
        private static readonly Logger logger = LogManager.GetCurrentClassLogger();

        private Dictionary<string, string> users = new Dictionary<string, string>()
        {
            {"Cristiano","password123"},
            {"Ronaldo","password123"},
        };

        public bool Login(string username, string password)
        {
            logger.Info($"Login attempt has made: {username}");

            if (!users.ContainsKey(username))
            {
                logger.Warn($"Login Failed:Incorrect password for user {username}");
                Console.WriteLine("Invalid Username and password");
                return false;
            }
            logger.Info($"Login successful for the username: {username}");
            Console.WriteLine("Login successful");
            return true;
        }
    }
}

class Program
{
    static void Main()
    {
        var config = new NLog.Config.LoggingConfiguration();
        var logfile = new NLog.Targets.FileTarget("logfile.txt") { FileName = "logfile.txt" };
        //var logconsole = new NLog.Targets.ConsoleTarget("logconsole");

        //config.AddRule(LogLevel.Debug, LogLevel.Fatal, logconsole);
        config.AddRule(LogLevel.Debug, LogLevel.Fatal, logfile);

        LogManager.Configuration = config;

        MenuAuth mauth = new MenuAuth();

        //simpleauth.Login("Cristiano", "password123");
        //simpleauth.Login("Ronaldo", "password123");

        var auth = new UserAuth();
        var encryption = new Encryption();
        bool ex = true;

        while(ex)
        {
            Console.WriteLine("\nWelcome to Secure Application:");
            Console.WriteLine("1. Login");
            Console.WriteLine("2. Register");
            Console.WriteLine("3. Exit");
            Console.WriteLine("Choose an option: ");
            
            string choice = Console.ReadLine();

            switch(choice)
            {
                case "1":
                    Console.WriteLine("enter Username: ");
                    string loginusername = Console.ReadLine();
                    Console.WriteLine("Enter Password: ");
                    string password = Console.ReadLine();

                    mauth.Login(loginusername, password);

                    if(auth.Authenticate(loginusername, password))
                    {
                        Console.Write("Enter encrypted data to decrypt: ");
                        string encryptedDatatoDecrypt = Console.ReadLine();

                        try
                        {
                            string decryptedData = encryption.Decrypt(encryptedDatatoDecrypt);
                            Console.WriteLine($"Decrypted Sensitive Data: {decryptedData}");
                        }
                        catch
                        {
                            Console.WriteLine("Invalid encrypted data.");
                        }
                    }
                    else
                    {
                        Console.WriteLine("Invalid username or password");
                    }
                    break;

                case "2":
                    Console.WriteLine("Enter new username: ");
                    string regusername = Console.ReadLine();
                    Console.WriteLine("Enter new password: ");
                    string regpassword = Console.ReadLine();
                    Console.WriteLine("Enter sensitive data to encrypt: ");
                    string sensitivedata = Console.ReadLine();

                    auth.Register(regusername, regpassword);

                    string encryptedData = encryption.Encrypt(sensitivedata);
                    Console.WriteLine("User registered Successfully");
                    Console.WriteLine($"Encrypted Sensitive Data: {encryptedData}");

                    Console.WriteLine("Remember your encrypted data: "+encryptedData);
                    break;

                case "3":
                    Console.WriteLine("Exiting...");
                    return;

                default:
                    Console.WriteLine("Invalid Choice. Try again!");
                    break;
            }

        }
    }
}