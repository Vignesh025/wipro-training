﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SOLIDprinciples
{
    public interface IUploadReport
    {
        string UploadReporter(string report);
    }
    public class ReportUploader : IUploadReport{
        public string UploadReporter(string report) {

            return $"Report Uploaded Successfully";
        }
    }
}
