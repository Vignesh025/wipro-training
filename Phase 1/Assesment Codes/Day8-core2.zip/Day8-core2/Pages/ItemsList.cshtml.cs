using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Day8_core2.Pages
{
    public class ItemsListModel : PageModel
    {
        public List<string> Items { get; set; } = new List<string> { "Item 1", "Item 2", "Item 3" };
        public void OnGet()
        {
            Items = AddItemModel.Items; // Retrieve items from shared static list
        }
    }
}
