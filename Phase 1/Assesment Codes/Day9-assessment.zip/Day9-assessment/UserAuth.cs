﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Day9_assessment
{
    public class UserAuth
    {
        public string Username { get; set; }

        public string Hashedpassword { get; set; }

        public void Register(string username, string hashedpassword)
        {
            Username = username;
            Hashedpassword = HashPassword(hashedpassword);
        }

        public bool Authenticate(string username, string password)
        {
            return Username == username && Hashedpassword == HashPassword(password);
        }

        private string HashPassword(string password)
        {
            using(SHA256 sha256 = SHA256.Create())
            {
                byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                return Encoding.UTF8.GetString(bytes);
            }
        }
    }
}
