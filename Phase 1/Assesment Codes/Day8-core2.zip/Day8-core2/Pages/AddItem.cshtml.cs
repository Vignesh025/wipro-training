using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Collections;

namespace Day8_core2.Pages
{
    public class AddItemModel : PageModel
    {
        public static List<string> Items = new List<string>();

        [BindProperty]
        public string NewItem { get; set; }
        //public void OnGet()
        //{
        //}
        public IActionResult OnPost()
        {
            if (!string.IsNullOrEmpty(NewItem))
            {
                Items.Add(NewItem);
            }
            return RedirectToPage("ItemsList");
        }
    }
}
