﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SOLIDprinciples
{
    public class ReportGenerator
    {
        public string GenerateReport() {
            return "Report Generated.";
        }
    }
}
