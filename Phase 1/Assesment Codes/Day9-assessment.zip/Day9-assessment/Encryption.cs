﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Intrinsics.Arm;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Day9_assessment
{
    public class Encryption
    {
        private readonly byte[] encryptionkey = Encoding.UTF8.GetBytes("A16ByteSecureKeyA16ByteSecureKey");

        public string Encrypt(string plaintext)
        {
            using (System.Security.Cryptography.Aes aes = System.Security.Cryptography.Aes.Create())
            {
                aes.Key = encryptionkey;
                aes.GenerateIV();

                ICryptoTransform encrypter = aes.CreateEncryptor(aes.Key, aes.IV);
                byte[] plainbytes = Encoding.UTF8.GetBytes(plaintext);
                byte[] cipherbytes = encrypter.TransformFinalBlock(plainbytes, 0, plainbytes.Length);

                return Convert.ToBase64String(cipherbytes);
            }
        }

        public string Decrypt(string ciphertext)
        {
            string[] parts = ciphertext.Split('|');
            byte[] iv = Convert.FromBase64String(parts[0]);
            byte[] cipherBytes = Convert.FromBase64String(parts[1]);

            using (System.Security.Cryptography.Aes aes = System.Security.Cryptography.Aes.Create())
            {
                aes.Key = encryptionkey;
                aes.IV = iv;

                ICryptoTransform decrypter = aes.CreateDecryptor(aes.Key, aes.IV);
                byte[] plainBytes = decrypter.TransformFinalBlock(cipherBytes, 0, cipherBytes.Length);

                return Encoding.UTF8.GetString(plainBytes);
            }
        }
    }
}
